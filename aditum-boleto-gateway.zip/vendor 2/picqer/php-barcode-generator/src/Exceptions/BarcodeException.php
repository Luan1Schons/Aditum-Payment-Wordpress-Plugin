<?php

namespace Picqer\Barcode\Exceptions;

class BarcodeException extends \Exception {}