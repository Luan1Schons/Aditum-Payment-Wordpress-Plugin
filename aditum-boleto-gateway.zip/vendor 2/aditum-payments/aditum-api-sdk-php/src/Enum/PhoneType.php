<?php

namespace AditumPayments\ApiSDK\Enum;

abstract class PhoneType {
    public const RESIDENCIAL  = 1;
    public const COMERCIAL    = 2;
    public const VOICEMAIL    = 3;
    public const TEMPORARY    = 4;
    public const MOBILE       = 5;

}